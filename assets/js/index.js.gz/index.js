!function(){var e,o;console.log("\nHolis!\nWelcome to my personal site!\n\n"),e=JSON.parse(localStorage.getItem("dark-mode")),document.getElementById("dark-mode").checked=e,o=document.getElementById("dark-mode"),console.log(o),o.onclick=function(){var e;e=o.checked,document.getElementById("dark-mode"),localStorage.setItem("dark-mode",e)}}();
//# sourceMappingURL=index.js.map
